#include <stdio.h>

int main() {
	char a[256];
	scanf("%s", a);
	printf("%s\n", a);
  return 0;
}